import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

public class WebScrapperTest {

    // method to initialize selenium webdriver for chrome
    WebDriver createDriver() {
        try {
                System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver/chromedriver.exe");
                return new ChromeDriver(getChromeOptions());
        } catch (Exception e) {
            System.out.println("Error while initialising chrome driver: " + e.getMessage());
            return null;
        }
    }

    // method to define and associate chrome options
    private ChromeOptions getChromeOptions() {
        ChromeOptions options = new ChromeOptions();
        try {
            options.setCapability("browserName", "chrome");
            options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
            options.setExperimentalOption("useAutomationExtension", false);
            options.addArguments("--start-maximized");
            options.addArguments("--incognito");
            options.addArguments("--disable-extensions");
            options.addArguments("--disable-site-isolation-trials");
            options.addArguments("--disable-gpu");
            options.addArguments("--disable-web-security");
            options.addArguments("--disable-infobars");
            options.addArguments("--disable-dev-shm-usage");
            options.addArguments("--ignore-certificate-errors");
            options.addArguments("--allow-running-insecure-content");
            options.addArguments("--allow-cross-origin-auth-prompt");
            HashMap<String, Object> chromePrefs = new HashMap<String, Object>(); options.setCapability("browserName", "chrome");
            chromePrefs.put("profile.default_content_settings.popups", 0);
            options.setExperimentalOption("prefs", chromePrefs);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return options;
    }

    //Test to run google search and capture the links in excel sheet
    //destination excel in path : src\main\resources\GoogleSearchLinks.xls
    @ParameterizedTest
    @CsvSource({"Messi"}) //parse the search text in the excel
    public void runWebScraperTest(String searchText) throws Exception
    {
        WebDriver driver = createDriver(); // driver initialisation
        driver.get("https://www.google.com/"); // URL to navigate
        driver.manage().timeouts().pageLoadTimeout(60, SECONDS);
        WebElement googleSearchField = driver.findElement(By.xpath("//input[@title='Search']"));
        googleSearchField.sendKeys(searchText); // setting the search text
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        googleSearchField.sendKeys(Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        List<WebElement> searchLinks = driver.findElements(By.xpath("//div[@id='search']//a[contains(@href,'"+ searchText +"')]")); //Fetching the relevant href links from the search result page and storing in the List
        String[] linksArray =new String[3];
        String excelFilepath = new File("src/main/resources/").getCanonicalPath(); // getting excel path
        try {
            for (WebElement link : searchLinks) {
                System.out.println("search link-->" + link.getText() + " and href =" + link.getAttribute("href"));
                linksArray[0] = searchText;
                linksArray[1] = link.getText();
                linksArray[2] = link.getAttribute("href");
                writeExcel(excelFilepath, "GoogleSearchLinks.xls", "Sheet1", linksArray);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        driver.quit(); // quit the driver post execution
    }

    //generic method to write the values in excel
    public void writeExcel(String filePath,String fileName,String sheetName,String[] dataToWrite) throws IOException {

        //Create an object of File class to open xlsx file

        File file =    new File(filePath+"\\"+fileName);

        //Create an object of FileInputStream class to read excel file

        FileInputStream inputStream = new FileInputStream(file);

        Workbook workbook = null;

        //Find the file extension by splitting  file name in substring and getting only extension name

        String fileExtensionName = fileName.substring(fileName.indexOf("."));

        //Check condition if the file is xlsx file

        if(fileExtensionName.equals(".xlsx")){

            //If it is xlsx file then create object of XSSFWorkbook class

            workbook = new XSSFWorkbook(inputStream);

        }

        //Check condition if the file is xls file

        else if(fileExtensionName.equals(".xls")){

            //If it is xls file then create object of XSSFWorkbook class

            workbook = new HSSFWorkbook(inputStream);

        }

        //Read excel sheet by sheet name

        Sheet sheet = workbook.getSheet(sheetName);

        //Get the current count of rows in excel file

        int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();

        //Get the first row from the sheet

        Row row = sheet.getRow(0);

        //Create a new row and append it at last of sheet

        Row newRow = sheet.createRow(rowCount+1);

        //Create a loop over the cell of newly created Row

        for(int j = 0; j < dataToWrite.length; j++){

            //Fill data in row

            Cell cell = newRow.createCell(j);

            cell.setCellValue(dataToWrite[j]);

        }

        //Close input stream

        inputStream.close();

        //Create an object of FileOutputStream class to create write data in excel file

        FileOutputStream outputStream = new FileOutputStream(file);

        //write data in the excel file

        workbook.write(outputStream);

        //close output stream

        outputStream.close();

    }

}
